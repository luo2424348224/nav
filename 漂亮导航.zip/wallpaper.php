<?php
error_reporting(0);
$s = $_GET['s'];
if($_GET['idx'] == ''){
 $str=file_get_contents('http://cn.bing.com/HPImageArchive.aspx?idx=0&n=1');
}
else{
 $str=file_get_contents('http://cn.bing.com/HPImageArchive.aspx?idx='.$_GET['idx'].'&n=1');
}
if(preg_match("/<url>(.+?)<\/url>/ies",$str,$matches)){
$imgurl='http://cn.bing.com'.$matches[1];
if($s == 'big'){
 $imgurl=str_replace("1366x768","1920x1080",$imgurl);
 }
}
if($imgurl){
header('Content-Type: image/JPEG');
@ob_end_clean();
@readfile($imgurl);
@flush(); @ob_flush();
exit();
}else{
exit('error');
}
?>