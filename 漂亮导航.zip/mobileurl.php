<?php
 function curl_request ( $url , $post = '' , $cookie = '' ,  $returnCookie = 0 ) {
	 $ua ='Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1 (compatible; Baiduspider-render/2.0; +http://www.baidu.com/search/spider.html)' ;
			$curl  =  curl_init ( ) ;
			curl_setopt ( $curl , CURLOPT_URL ,  $url ) ;
			curl_setopt ( $curl , CURLOPT_USERAGENT , $ua ) ;
			curl_setopt ( $curl , CURLOPT_FOLLOWLOCATION ,  1 ) ;
			curl_setopt ( $curl , CURLOPT_AUTOREFERER ,  1 ) ;
			curl_setopt ( $curl , CURLOPT_REFERER ,  "https://www.baidu.com" ) ;
			if ( $post )  {
				 curl_setopt ( $curl , CURLOPT_POST ,  1 ) ;
				 curl_setopt ( $curl , CURLOPT_POSTFIELDS ,  http_build_query ( $post ) ) ;
			}
			if ( $cookie )  {
				 curl_setopt ( $curl , CURLOPT_COOKIE ,  $cookie ) ;
			}
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt ( $curl , CURLOPT_HEADER ,  $returnCookie ) ;
			curl_setopt ( $curl , CURLOPT_TIMEOUT ,  10 ) ;
			curl_setopt ( $curl , CURLOPT_RETURNTRANSFER ,  1 ) ;
			$data  =  curl_exec ( $curl ) ;
			if  ( curl_errno ( $curl ) )  {
				 return  curl_error ( $curl ) ;
			}
			curl_close ( $curl ) ;
			if ( $returnCookie ) {
				 list ( $header ,  $body )  =  explode ( "\r\n\r\n" ,  $data ,  2 ) ;
				 preg_match_all ( "/Set\-Cookie:([^;]*);/" ,  $header ,  $matches ) ;
				 $info [ 'cookie' ]   =  substr ( $matches [ 1 ] [ 0 ] ,  1 ) ;
				 $info [ 'content' ]  =  $body ;
				 return  $info ;
			} else {
				 echo  $data ;
				
			}
}
$url=$_SERVER["QUERY_STRING"];
curl_request ( $url, $post = '' , $cookie = '' ,  $returnCookie = 0 );
?>